<?php
require_once __DIR__ . '/config.php';
$db = get_db();
ensure_schema($db);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$product = $id > 0 ? fetch_product($db, $id) : null;
if (!$product) {
    http_response_code(404);
}

require_once __DIR__ . '/seo.php';
// Preparar imagem de capa para OG/twitter
$headImages = [];
if ($product && !empty($product['image_urls'])) {
    $headImages = array_filter(array_map('trim', explode(',', (string)$product['image_urls'])));
}
$headCover = $headImages[0] ?? 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?= $product ? htmlspecialchars($product['name']) . ' • PlugPlay Shop' : 'Produto não encontrado • PlugPlay Shop' ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css" />
    <?php
      $canonical = seo_canonical('/product.php?id=' . (int)$id);
      $title = $product ? ($product['name'] . ' • PlugPlay Shop') : 'Produto não encontrado • PlugPlay Shop';
      $desc = $product ? (mb_substr(strip_tags($product['description'] ?? ''), 0, 160)) : 'Produto não encontrado';
      $priceCur = $product ? (string)($product['currency'] ?? 'USD') : 'USD';
      $priceVal = $product ? (float)$product['price'] : 0.0;
      seo_meta([
        'title' => $title,
        'description' => $desc,
        'canonical' => $canonical,
        'image' => $headCover,
        'type' => $product ? 'product' : 'website',
      ]);
      if ($product) {
        $siteUrl = seo_site_url();
        seo_jsonld([
          '@context' => 'https://schema.org',
          '@type' => 'Product',
          'name' => $product['name'],
          'description' => $product['description'],
          'image' => [$headCover],
          'sku' => (string)$product['id'],
          'offers' => [
            '@type' => 'Offer',
            'url' => $siteUrl . '/product.php?id=' . (int)$product['id'],
            'priceCurrency' => $priceCur,
            'price' => number_format($priceVal, 2, '.', ''),
            'availability' => 'https://schema.org/InStock'
          ]
        ]);
      }
    ?>
</head>
<body>
    <header class="site-header">
        <div class="container header-inner">
            <div class="brand">
                <span class="logo">🛍️</span>
                <a class="name" href="index.php">PlugPlay Shop</a>
            </div>
            <nav class="actions">
                <a class="btn" href="index.php">Voltar</a>
            </nav>
        </div>
    </header>

    <main class="container product-page">
        <?php if (!$product): ?>
            <h1>Produto não encontrado</h1>
            <p>Este produto pode ter sido removido ou o link está incorreto.</p>
        <?php else: ?>
            <?php $images = array_filter(array_map('trim', explode(',', (string)$product['image_urls'])));
            if (empty($images)) {
                $images = ['https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop'];
            }
            ?>
            <div class="product-layout">
                <div class="gallery">
                    <div class="slider" id="slider">
                        <?php foreach ($images as $idx => $img): ?>
                            <div class="slide<?= $idx === 0 ? ' active' : '' ?>">
                                <img src="<?= htmlspecialchars($img) ?>" alt="Imagem <?= $idx+1 ?> de <?= htmlspecialchars($product['name']) ?>" />
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (count($images) > 1): ?>
                    <div class="slider-controls">
                        <button class="prev" id="prevBtn">◀</button>
                        <button class="next" id="nextBtn">▶</button>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="details">
                    <h1><?= htmlspecialchars($product['name']) ?></h1>
                    <?php if (!empty($product['category'])): ?>
                        <span class="badge large"><?= htmlspecialchars($product['category']) ?></span>
                    <?php endif; ?>
                    <p class="desc"><?= nl2br(htmlspecialchars($product['description'])) ?></p>
                    <div class="buy">
                        <span class="price big"><?= htmlspecialchars(format_money((float)$product['price'], (string)($product['currency'] ?? 'USD'))) ?></span>
                        <?php if (!empty($product['affiliate_url'])): ?>
                            <a class="btn primary big" href="go.php?id=<?= (int)$product['id'] ?>&src=product" target="_blank" rel="noopener noreferrer">Comprar agora</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <?php if ($product): ?>
    <script>
    (function(){
        const slides = Array.from(document.querySelectorAll('.slide'));
        let idx = slides.findIndex(s => s.classList.contains('active'));
        function show(i){
            slides.forEach(s => s.classList.remove('active'));
            idx = (i + slides.length) % slides.length;
            slides[idx].classList.add('active');
        }
        const prev = document.getElementById('prevBtn');
        const next = document.getElementById('nextBtn');
        if (prev && next) {
            prev.addEventListener('click', () => show(idx - 1));
            next.addEventListener('click', () => show(idx + 1));
        }
    })();
    </script>
    <?php endif; ?>
</body>
</html>