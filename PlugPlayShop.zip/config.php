<?php
// Configura conexão e schema do MySQL para PlugPlay Shop

function load_env(): array {
    $envPath = __DIR__ . '/.env';
    $vars = [];
    if (is_file($envPath)) {
        $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (strpos(ltrim($line), '#') === 0) continue;
            $parts = explode('=', $line, 2);
            if (count($parts) === 2) {
                $key = trim($parts[0]);
                $val = trim($parts[1]);
                // Remove aspas
                if ((str_starts_with($val, '"') && str_ends_with($val, '"')) || (str_starts_with($val, "'") && str_ends_with($val, "'"))) {
                    $val = substr($val, 1, -1);
                }
                $vars[$key] = $val;
            }
        }
    }
    return $vars;
}

function get_db(): mysqli {
    $env = load_env();
    $host = $env['DB_HOST'] ?? '127.0.0.1';
    $user = $env['DB_USER'] ?? 'root';
    $pass = $env['DB_PASS'] ?? '';
    $dbName = $env['DB_NAME'] ?? 'plugplayshop';
    $port = isset($env['DB_PORT']) ? (int)$env['DB_PORT'] : (int)(ini_get('mysqli.default_port') ?: 3306);

    // Conecta sem banco para garantir criação
    $server = @new mysqli($host, $user, $pass, '', $port);
    if ($server->connect_errno) {
        http_response_code(500);
        die('<h2>Falha ao conectar ao MySQL</h2><p>' . htmlspecialchars($server->connect_error) . '</p>' .
            '<p>Configure suas credenciais em <code>.env</code> com, por exemplo:</p>' .
            '<pre>DB_HOST=127.0.0.1\nDB_USER=root\nDB_PASS=sua_senha\nDB_NAME=plugplayshop\nDB_PORT=3306</pre>');
    }
    $server->set_charset('utf8mb4');
    $server->query("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $server->close();

    $db = @new mysqli($host, $user, $pass, $dbName, $port);
    if ($db->connect_errno) {
        http_response_code(500);
        die('<h2>Falha ao selecionar DB</h2><p>' . htmlspecialchars($db->connect_error) . '</p>' .
            '<p>Verifique se o banco existe e se as credenciais no <code>.env</code> estão corretas.</p>');
    }
    $db->set_charset('utf8mb4');
    return $db;
}

function ensure_schema(mysqli $db): void {
    $db->query(
        'CREATE TABLE IF NOT EXISTS products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            description TEXT,
            price DECIMAL(10,2) DEFAULT 0,
            currency VARCHAR(3) NOT NULL DEFAULT "USD",
            category VARCHAR(100),
            image_urls TEXT,
            affiliate_url VARCHAR(500),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );

    // Migração suave: adicionar coluna currency se não existir (MySQL 8+)
    @ $db->query('ALTER TABLE products ADD COLUMN IF NOT EXISTS currency VARCHAR(3) NOT NULL DEFAULT "USD" AFTER price');

    // Tabela de cliques em links de afiliado
    $db->query(
        'CREATE TABLE IF NOT EXISTS clicks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            source VARCHAR(20),
            ip VARCHAR(45),
            user_agent VARCHAR(255),
            referer VARCHAR(500),
            utm_source VARCHAR(100),
            utm_medium VARCHAR(100),
            utm_campaign VARCHAR(100),
            landing_path VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_clicks_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );
    @$db->query('CREATE INDEX IF NOT EXISTS idx_clicks_product ON clicks(product_id)');
    @$db->query('CREATE INDEX IF NOT EXISTS idx_clicks_created ON clicks(created_at)');
    // Atualização de esquema (ignora erros se colunas já existem)
    @ $db->query('ALTER TABLE clicks ADD COLUMN IF NOT EXISTS utm_source VARCHAR(100)');
    @ $db->query('ALTER TABLE clicks ADD COLUMN IF NOT EXISTS utm_medium VARCHAR(100)');
    @ $db->query('ALTER TABLE clicks ADD COLUMN IF NOT EXISTS utm_campaign VARCHAR(100)');
    @ $db->query('ALTER TABLE clicks ADD COLUMN IF NOT EXISTS landing_path VARCHAR(255)');

    // Índices simples (ignora erro se IF NOT EXISTS não disponível)
    @$db->query('CREATE INDEX IF NOT EXISTS idx_category ON products(category)');
    @$db->query('CREATE INDEX IF NOT EXISTS idx_name ON products(name)');

    // Tabela de usuários para login simples
    $db->query(
        'CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );

    // Tentativas de login para rate limit/bloqueio
    $db->query(
        'CREATE TABLE IF NOT EXISTS login_attempts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100),
            ip VARCHAR(45),
            attempt_count INT DEFAULT 0,
            last_attempt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            locked_until TIMESTAMP NULL DEFAULT NULL,
            INDEX idx_login_user_ip (username, ip),
            INDEX idx_login_locked (locked_until)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );
    // Seed admin se não existir
    $res = $db->query("SELECT COUNT(*) as c FROM users WHERE username='admin'");
    $r = $res ? $res->fetch_assoc() : ['c' => 0];
    if ((int)$r['c'] === 0) {
        $hash = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $db->prepare('INSERT INTO users (username, password_hash) VALUES (?, ?)');
        $u = 'admin';
        $stmt->bind_param('ss', $u, $hash);
        $stmt->execute();
        $stmt->close();
    }

    // Seed básico se vazio
    $res = $db->query('SELECT COUNT(*) as c FROM products');
    $row = $res ? $res->fetch_assoc() : ['c' => 0];
    if ((int)$row['c'] === 0) {
        $samples = [
            [
                'name' => 'Fone Bluetooth Pro',
                'description' => 'Som nítido, cancelamento de ruído e bateria de longa duração.',
                'price' => 349.90,
                'category' => 'Eletrônicos',
                'images' => [
                    'https://images.unsplash.com/photo-1518444027693-0f5f39de3f4c?q=80&w=1200&auto=format&fit=crop',
                    'https://images.unsplash.com/photo-1511367461989-f85a21fda167?q=80&w=1200&auto=format&fit=crop'
                ],
                'affiliate' => 'https://example.com/affiliado/fone-pro'
            ],
            [
                'name' => 'Smartwatch Active',
                'description' => 'Monitore saúde, notificações e treinos com estilo.',
                'price' => 599.00,
                'category' => 'Fitness',
                'images' => [
                    'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=1200&auto=format&fit=crop',
                    'https://images.unsplash.com/photo-1541532713592-79a0317b6b77?q=80&w=1200&auto=format&fit=crop'
                ],
                'affiliate' => 'https://example.com/affiliado/smartwatch-active'
            ],
            [
                'name' => 'Mouse Gamer X',
                'description' => 'Alta precisão, RGB e ergonomia para longas sessões.',
                'price' => 249.00,
                'category' => 'Eletrônicos',
                'images' => [
                    'https://images.unsplash.com/photo-1544829097-3eac1049f3c3?q=80&w=1200&auto=format&fit=crop',
                    'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=1200&auto=format&fit=crop'
                ],
                'affiliate' => 'https://example.com/affiliado/mouse-gamer-x'
            ],
            [
                'name' => 'Caixa de Som Portátil',
                'description' => 'Graves potentes e resistência à água para qualquer momento.',
                'price' => 399.99,
                'category' => 'Eletrônicos',
                'images' => [
                    'https://images.unsplash.com/photo-1557682224-5b8590b01584?q=80&w=1200&auto=format&fit=crop'
                ],
                'affiliate' => 'https://example.com/affiliado/caixa-portatil'
            ],
            [
                'name' => 'Cafeteira Compacta',
                'description' => 'Seu café perfeito em minutos, design minimalista.',
                'price' => 329.90,
                'category' => 'Casa',
                'images' => [
                    'https://images.unsplash.com/photo-1502945015378-0e284ca06ccb?q=80&w=1200&auto=format&fit=crop'
                ],
                'affiliate' => 'https://example.com/affiliado/cafeteira-compacta'
            ],
            [
                'name' => 'Teclado Mecânico TKL',
                'description' => 'Feedback tátil, switches silenciosos e construção robusta.',
                'price' => 459.00,
                'category' => 'Eletrônicos',
                'images' => [
                    'https://images.unsplash.com/photo-1515879218367-8466d910aaa4?q=80&w=1200&auto=format&fit=crop'
                ],
                'affiliate' => 'https://example.com/affiliado/teclado-tkl'
            ],
        ];

        $stmt = $db->prepare('INSERT INTO products (name, description, price, currency, category, image_urls, affiliate_url) VALUES (?, ?, ?, ?, ?, ?, ?)');
        foreach ($samples as $s) {
            $imagesStr = implode(',', $s['images']);
            $cur = 'USD';
            $stmt->bind_param('ssdssss', $s['name'], $s['description'], $s['price'], $cur, $s['category'], $imagesStr, $s['affiliate']);
            $stmt->execute();
        }
        $stmt->close();
    }
}

function fetch_products(mysqli $db): array {
    $out = [];
    $res = $db->query('SELECT * FROM products ORDER BY created_at DESC');
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $out[] = $row;
        }
        $res->close();
    }
    return $out;
}

function fetch_product(mysqli $db, int $id): ?array {
    $stmt = $db->prepare('SELECT * FROM products WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res ? $res->fetch_assoc() : null;
    $stmt->close();
    return $row ?: null;
}

function insert_product(mysqli $db, array $data): bool {
    $stmt = $db->prepare('INSERT INTO products (name, description, price, currency, category, image_urls, affiliate_url) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $name = $data['name'] ?? '';
    $desc = $data['description'] ?? '';
    $price = isset($data['price']) ? (float)$data['price'] : 0.0;
    $currency = strtoupper(substr((string)($data['currency'] ?? 'USD'), 0, 3));
    if (!in_array($currency, ['USD','BRL','EUR'], true)) { $currency = 'USD'; }
    $cat = $data['category'] ?? '';
    $images = $data['image_urls'] ?? '';
    $aff = $data['affiliate_url'] ?? '';
    $stmt->bind_param('ssdssss', $name, $desc, $price, $currency, $cat, $images, $aff);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function update_product(mysqli $db, int $id, array $data): bool {
    $stmt = $db->prepare('UPDATE products SET name = ?, description = ?, price = ?, currency = ?, category = ?, image_urls = ?, affiliate_url = ? WHERE id = ?');
    $name = $data['name'] ?? '';
    $desc = $data['description'] ?? '';
    $price = isset($data['price']) ? (float)$data['price'] : 0.0;
    $currency = strtoupper(substr((string)($data['currency'] ?? 'USD'), 0, 3));
    if (!in_array($currency, ['USD','BRL','EUR'], true)) { $currency = 'USD'; }
    $cat = $data['category'] ?? '';
    $images = $data['image_urls'] ?? '';
    $aff = $data['affiliate_url'] ?? '';
    $stmt->bind_param('ssdssssi', $name, $desc, $price, $currency, $cat, $images, $aff, $id);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function delete_product(mysqli $db, int $id): bool {
    $stmt = $db->prepare('DELETE FROM products WHERE id = ?');
    $stmt->bind_param('i', $id);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

// CSRF simples por sessão
function csrf_token(): string {
    if (!isset($_SESSION)) { session_start(); }
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf_token'];
}

function check_csrf(?string $token): bool {
    if (!isset($_SESSION)) { session_start(); }
    return isset($_SESSION['csrf_token']) && is_string($token) && hash_equals($_SESSION['csrf_token'], $token);
}

// Formata preço conforme moeda
function format_money(float $amount, string $currency): string {
    $cur = strtoupper(substr($currency, 0, 3));
    switch ($cur) {
        case 'USD':
            return 'US$ ' . number_format($amount, 2, '.', ',');
        case 'EUR':
            return '€ ' . number_format($amount, 2, ',', '.');
        case 'BRL':
        default:
            return 'R$ ' . number_format($amount, 2, ',', '.');
    }
}

function record_click(mysqli $db, int $productId, string $source = ''): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250);
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    $refShort = substr($ref, 0, 490);
    $utm_source = '';
    $utm_medium = '';
    $utm_campaign = '';
    $landing_path = '';
    // Extrai UTM do referer
    if ($ref) {
        $parts = parse_url($ref);
        if (!empty($parts['query'])) {
            parse_str($parts['query'], $q);
            $utm_source = substr((string)($q['utm_source'] ?? ''), 0, 100);
            $utm_medium = substr((string)($q['utm_medium'] ?? ''), 0, 100);
            $utm_campaign = substr((string)($q['utm_campaign'] ?? ''), 0, 100);
        }
        $landing_path = isset($parts['path']) ? substr($parts['path'], 0, 250) : '';
    }
    $stmt = $db->prepare('INSERT INTO clicks (product_id, source, ip, user_agent, referer, utm_source, utm_medium, utm_campaign, landing_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->bind_param('issssssss', $productId, $source, $ip, $ua, $refShort, $utm_source, $utm_medium, $utm_campaign, $landing_path);
    $stmt->execute();
    $stmt->close();
}

function get_analytics(mysqli $db): array {
    $metrics = [
        'total_products' => 0,
        'total_clicks' => 0,
        'avg_price' => 0.0,
        'min_price' => 0.0,
        'max_price' => 0.0,
        'categories' => [],
        'top_products' => [],
        'recent_clicks' => [],
    ];

    // Totais e preço
    if ($res = $db->query('SELECT COUNT(*) as c, AVG(price) as avgp, MIN(price) as minp, MAX(price) as maxp FROM products')) {
        $r = $res->fetch_assoc();
        $metrics['total_products'] = (int)$r['c'];
        $metrics['avg_price'] = (float)$r['avgp'];
        $metrics['min_price'] = (float)$r['minp'];
        $metrics['max_price'] = (float)$r['maxp'];
        $res->close();
    }
    if ($res = $db->query('SELECT COUNT(*) as c FROM clicks')) {
        $r = $res->fetch_assoc();
        $metrics['total_clicks'] = (int)$r['c'];
        $res->close();
    }

    // Categorias
    if ($res = $db->query('SELECT category, COUNT(*) as c FROM products WHERE category IS NOT NULL AND category <> "" GROUP BY category ORDER BY c DESC')) {
        while ($row = $res->fetch_assoc()) {
            $metrics['categories'][] = $row;
        }
        $res->close();
    }

    // Top produtos por cliques
    $sqlTop = 'SELECT p.id, p.name, p.category, p.price, p.currency, COUNT(c.id) as clicks
               FROM products p LEFT JOIN clicks c ON c.product_id = p.id
               GROUP BY p.id, p.name, p.category, p.price, p.currency
               ORDER BY clicks DESC, p.created_at DESC
               LIMIT 10';
    if ($res = $db->query($sqlTop)) {
        while ($row = $res->fetch_assoc()) {
            $metrics['top_products'][] = $row;
        }
        $res->close();
    }

    // Últimos cliques
    if ($res = $db->query('SELECT c.created_at, c.source, c.ip, c.utm_source, c.utm_medium, c.utm_campaign, c.landing_path, p.name FROM clicks c JOIN products p ON p.id = c.product_id ORDER BY c.created_at DESC LIMIT 20')) {
        while ($row = $res->fetch_assoc()) {
            $metrics['recent_clicks'][] = $row;
        }
        $res->close();
    }

    return $metrics;
}