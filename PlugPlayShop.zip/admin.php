<?php
session_start();
require_once __DIR__ . '/config.php';
$db = get_db();
ensure_schema($db);

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$msg = '';
$type = 'info';
if (isset($_SESSION['flash'])) {
    if (is_array($_SESSION['flash'])) {
        $msg = (string)($_SESSION['flash']['msg'] ?? '');
        $type = (string)($_SESSION['flash']['type'] ?? 'info');
    } else {
        $msg = (string)$_SESSION['flash'];
        $type = 'info';
    }
    unset($_SESSION['flash']);
}
// Persistência do per_page via cookie (aplica no próximo carregamento)
if (isset($_GET['per_page'])) {
    $cookieVal = max(1, min(200, (int)$_GET['per_page']));
    setcookie('per_page', (string)$cookieVal, time() + 60*60*24*30, '/');
}
// Persistência de filtros principais
if (isset($_GET['q'])) {
    $qCookie = substr(trim((string)$_GET['q']), 0, 200);
    setcookie('q', $qCookie, time() + 60*60*24*30, '/');
}
if (isset($_GET['sort'])) {
    $sortVal = (string)$_GET['sort'];
    $sortCookie = in_array($sortVal, ['', 'clicks', 'price'], true) ? $sortVal : '';
    setcookie('sort', $sortCookie, time() + 60*60*24*30, '/');
}
if (isset($_GET['categories'])) {
    $catsArr = (array)$_GET['categories'];
    $catsArr = array_filter(array_map(function($x){ return substr(trim((string)$x), 0, 80); }, $catsArr));
    $catsCsv = implode(',', $catsArr);
    setcookie('categories', $catsCsv, time() + 60*60*24*30, '/');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name'])) {
    if (!check_csrf($_POST['csrf'] ?? null)) {
        $msg = 'Sessão expirada ou inválida. Tente novamente.';
        $type = 'error';
    } else {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price = trim($_POST['price'] ?? '0');
        $currency = strtoupper(substr(trim((string)($_POST['currency'] ?? 'USD')), 0, 3));
        if (!in_array($currency, ['USD','BRL','EUR'], true)) { $currency = 'USD'; }
        $category = trim($_POST['category'] ?? '');
        $affiliate = trim($_POST['affiliate_url'] ?? '');
        $images_raw = trim($_POST['image_urls'] ?? '');
        // normaliza separadores
        $images_raw = str_replace([';', '\n', '\r'], [',', ',', ''], $images_raw);
        // limpa espaços extras
        $images = array_filter(array_map('trim', explode(',', $images_raw)));
        $image_urls = implode(',', $images);

        $ok = insert_product($db, [
            'name' => $name,
            'description' => $description,
            'price' => $price,
            'currency' => $currency,
            'category' => $category,
            'image_urls' => $image_urls,
            'affiliate_url' => $affiliate,
        ]);
        $msg = $ok ? 'Produto adicionado com sucesso!' : 'Falha ao adicionar produto.';
        $type = $ok ? 'success' : 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin • PlugPlay Shop</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css" />
</head>
<body>
    <header class="site-header">
        <div class="container header-inner">
            <div class="brand">
                <span class="logo">⚙️</span>
                <span class="name">Admin</span>
            </div>
            <nav class="actions">
                <a class="btn" href="index.php">Voltar à loja</a>
                <a class="btn" href="logout.php">Sair</a>
                <a class="btn" href="settings.php">Configurações</a>
            </nav>
        </div>
    </header>

    <main class="container">
        <h1>Administração</h1>
        <?php if ($msg): ?>
            <div class="notice <?= htmlspecialchars($type) ?>"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <section>
            <h2>Cadastrar novo produto</h2>
            <form method="post" class="form">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>" />
                <div class="form-row">
                    <label>Nome</label>
                    <input type="text" name="name" required placeholder="Ex: Fone Bluetooth Pro" />
                </div>
                <div class="form-row">
                    <label>Descrição</label>
                    <textarea name="description" rows="4" placeholder="Destaques, benefícios e diferenciais."></textarea>
                </div>
                <div class="form-row">
                    <label>Preço</label>
                    <input type="number" step="0.01" name="price" required placeholder="0.00" />
                </div>
                <div class="form-row">
                    <label>Moeda</label>
                    <select name="currency" style="height: 42px; border-radius: 10px; border: 1px solid var(--border); background: var(--card); color: var(--text); padding: 0 12px;">
                        <option value="USD" selected>USD (US$)</option>
                        <option value="BRL">BRL (R$)</option>
                        <option value="EUR">EUR (€)</option>
                    </select>
                </div>
                <div class="form-row">
                    <label>Categoria</label>
                    <input type="text" name="category" placeholder="Ex: Eletrônicos" />
                </div>
                <div class="form-row">
                    <label>Links de Imagem (separados por vírgula)</label>
                    <textarea name="image_urls" rows="3" placeholder="https://... , https://..."></textarea>
                </div>
                <div class="form-row">
                    <label>Link de Afiliado</label>
                    <input type="url" name="affiliate_url" placeholder="https://seu-link-de-afiliado" />
                </div>
                <div class="form-actions">
                    <button class="btn primary" type="submit">Salvar produto</button>
                </div>
            </form>
        </section>

        <?php $analytics = get_analytics($db); ?>
        <section>
            <h2>Métricas</h2>
            <div class="grid" style="grid-template-columns: repeat(4, 1fr);">
                <div class="card"><div class="card-body"><div class="card-title">Produtos</div><div class="price"><?= (int)$analytics['total_products'] ?></div></div></div>
                <div class="card"><div class="card-body"><div class="card-title">Cliques</div><div class="price"><?= (int)$analytics['total_clicks'] ?></div></div></div>
                <div class="card"><div class="card-body"><div class="card-title">Preço médio</div><div class="price">R$ <?= number_format((float)$analytics['avg_price'], 2, ',', '.') ?></div></div></div>
                <div class="card"><div class="card-body"><div class="card-title">Faixa de preço</div><div class="price">R$ <?= number_format((float)$analytics['min_price'], 2, ',', '.') ?> — <?= number_format((float)$analytics['max_price'], 2, ',', '.') ?></div></div></div>
            </div>

            <h3>Distribuição por categorias</h3>
            <div class="grid" style="grid-template-columns: 1fr 1fr;">
                <div class="card"><div class="card-body">
                    <?php if (!empty($analytics['categories'])): ?>
                        <?php foreach ($analytics['categories'] as $cat): ?>
                            <div style="display:flex; align-items:center; gap:10px; margin:6px 0;">
                                <span class="badge"><?= htmlspecialchars($cat['category']) ?></span>
                                <div style="flex:1; background:#222642; height:8px; border-radius:999px; overflow:hidden;">
                                    <div style="width: <?= min(100, 8 + (int)$cat['c'] * 12) ?>%; height:100%; background:#7c5cff;"></div>
                                </div>
                                <span><?= (int)$cat['c'] ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="desc">Sem categorias cadastradas.</p>
                    <?php endif; ?>
                </div></div>

                <div class="card"><div class="card-body">
                    <div class="card-title">Top produtos por cliques</div>
                    <table style="width:100%; border-collapse:collapse;">
                        <thead>
                            <tr style="color:#cbd1e6;">
                                <th style="text-align:left; padding:6px;">Produto</th>
                                <th style="text-align:left; padding:6px;">Categoria</th>
                                <th style="text-align:right; padding:6px;">Preço</th>
                                <th style="text-align:right; padding:6px;">Cliques</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($analytics['top_products'] as $row): ?>
                                <tr>
                                    <td style="padding:6px;">
                                        <a href="product.php?id=<?= (int)$row['id'] ?>" class="badge">#<?= (int)$row['id'] ?></a>
                                        <?= htmlspecialchars($row['name']) ?>
                                    </td>
                                    <td style="padding:6px;"><?= htmlspecialchars($row['category']) ?></td>
                                    <td style="padding:6px; text-align:right;"><?= htmlspecialchars(format_money((float)$row['price'], (string)($row['currency'] ?? 'USD'))) ?></td>
                                    <td style="padding:6px; text-align:right; font-weight:700;"><?= (int)$row['clicks'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div></div>
            </div>

            <h3>Últimos cliques</h3>
            <div class="card"><div class="card-body">
                <?php if (!empty($analytics['recent_clicks'])): ?>
                    <table style="width:100%; border-collapse:collapse;">
                        <thead>
                            <tr style="color:#cbd1e6;">
                                <th style="text-align:left; padding:6px;">Data</th>
                                <th style="text-align:left; padding:6px;">Origem</th>
                                <th style="text-align:left; padding:6px;">Produto</th>
                                <th style="text-align:left; padding:6px;">IP</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($analytics['recent_clicks'] as $c): ?>
                                <tr>
                                    <td style="padding:6px;"><?= htmlspecialchars($c['created_at']) ?></td>
                                    <td style="padding:6px;"><?= htmlspecialchars($c['source']) ?></td>
                                    <td style="padding:6px;"><?= htmlspecialchars($c['name']) ?></td>
                                    <td style="padding:6px;"><?= htmlspecialchars($c['ip']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="desc">Ainda não há cliques registrados.</p>
                <?php endif; ?>
            </div></div>
        </section>

        <?php
        // Listagem de produtos com busca e ordenação
        $q = trim($_GET['q'] ?? (isset($_COOKIE['q']) ? (string)$_COOKIE['q'] : ''));
        $sort = $_GET['sort'] ?? (isset($_COOKIE['sort']) ? (string)$_COOKIE['sort'] : '');
        $sqlList = 'SELECT p.*, COALESCE(cnt.c,0) as clicks_count FROM products p
                    LEFT JOIN (
                        SELECT product_id, COUNT(*) as c FROM clicks GROUP BY product_id
                    ) cnt ON cnt.product_id = p.id';
        $where = '';
        if ($q !== '') {
            $q_like = '%' . $db->real_escape_string($q) . '%';
            $where = " WHERE p.name LIKE '$q_like' OR p.category LIKE '$q_like' ";
        }
        $order = ' ORDER BY p.created_at DESC ';
        if ($sort === 'clicks') $order = ' ORDER BY clicks_count DESC, p.created_at DESC ';
        if ($sort === 'price') $order = ' ORDER BY p.price DESC ';
        // filtros avançados
        $selCats = isset($_GET['categories']) ? (array)$_GET['categories'] : (isset($_COOKIE['categories']) ? array_filter(array_map('trim', explode(',', (string)$_COOKIE['categories']))) : []);
        $minPrice = isset($_GET['min_price']) && $_GET['min_price'] !== '' ? (float)$_GET['min_price'] : null;
        $maxPrice = isset($_GET['max_price']) && $_GET['max_price'] !== '' ? (float)$_GET['max_price'] : null;
        $conds = [];
        // Filtro por moeda
        $curSel = isset($_GET['currency']) ? strtoupper(substr((string)$_GET['currency'], 0, 3)) : '';
        if (!in_array($curSel, ['USD','BRL','EUR'], true)) { $curSel = ''; }
        if ($curSel !== '') { $conds[] = " p.currency = '" . $db->real_escape_string($curSel) . "' "; }
        if (!empty($selCats)) {
            $safeCats = array_map(function($x) use ($db) { return "'" . $db->real_escape_string($x) . "'"; }, $selCats);
            $conds[] = ' p.category IN (' . implode(',', $safeCats) . ') ';
        }
        if ($minPrice !== null && $minPrice >= 0) { $conds[] = ' p.price >= ' . (float)$minPrice . ' '; }
        if ($maxPrice !== null && $maxPrice >= 0) { $conds[] = ' p.price <= ' . (float)$maxPrice . ' '; }
        $where2 = '';
        if (!empty($conds)) { $where2 = ($where===''?' WHERE ':' AND ') . implode(' AND ', $conds); }
        // Paginação
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $perPage = isset($_GET['per_page'])
            ? max(1, min(200, (int)$_GET['per_page']))
            : (isset($_COOKIE['per_page']) ? max(1, min(200, (int)$_COOKIE['per_page'])) : 20);
        $offset = ($page - 1) * $perPage;

        // Total de produtos para as condições atuais
        $sqlCount = 'SELECT COUNT(*) as c FROM products p';
        $sqlCount .= $where . $where2; // sem ORDER/LIMIT
        $totalRows = 0;
        if ($rc = $db->query($sqlCount)) {
            $r = $rc->fetch_assoc();
            $totalRows = (int)$r['c'];
            $rc->close();
        }
        $totalPages = max(1, (int)ceil($totalRows / $perPage));

        // Lista paginada
        $sqlList .= $where . $where2 . $order . ' LIMIT ' . (int)$perPage . ' OFFSET ' . (int)$offset;
        $productsList = [];
        if ($res = $db->query($sqlList)) {
            while ($row = $res->fetch_assoc()) { $productsList[] = $row; }
            $res->close();
        }
        ?>
        <section id="produtos">
            <h2>Produtos</h2>
            <?php
            // opções de categorias para multiselect
            $cats = [];
            if ($rc = $db->query('SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category <> "" ORDER BY category')) {
                while ($row = $rc->fetch_assoc()) { $cats[] = $row['category']; }
                $rc->close();
            }
            ?>
            <form method="get" action="admin.php#produtos" class="form" style="grid-template-columns: 1.2fr 160px 1fr 1fr 140px; align-items: end;">
                <div class="form-row">
                    <label>Buscar (nome/categoria)</label>
                    <input type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Ex: Eletrônicos, Mouse..." />
                </div>
                <div class="form-row">
                    <label>Moeda</label>
                    <?php $curSel = strtoupper(substr((string)($_GET['currency'] ?? ''), 0, 3)); if (!in_array($curSel, ['USD','BRL','EUR'], true)) { $curSel = ''; } ?>
                    <select name="currency" style="height: 42px; border-radius: 10px; border: 1px solid var(--border); background: var(--card); color: var(--text); padding: 0 12px;">
                        <option value="">Todas</option>
                        <option value="USD" <?= $curSel==='USD'?'selected':''; ?>>USD (US$)</option>
                        <option value="BRL" <?= $curSel==='BRL'?'selected':''; ?>>BRL (R$)</option>
                        <option value="EUR" <?= $curSel==='EUR'?'selected':''; ?>>EUR (€)</option>
                    </select>
                </div>
                <div class="form-row">
                    <label>Ordenar por</label>
                    <select name="sort" style="height: 42px; border-radius: 10px; border: 1px solid var(--border); background: var(--card); color: var(--text); padding: 0 12px;">
                        <option value="">Mais recentes</option>
                        <option value="clicks" <?= $sort==='clicks'?'selected':''; ?>>Cliques</option>
                        <option value="price" <?= $sort==='price'?'selected':''; ?>>Preço</option>
                    </select>
                </div>
                <div class="form-row">
                    <label>Categorias</label>
                    <select name="categories[]" multiple size="4" style="min-height: 86px; border-radius: 10px; border: 1px solid var(--border); background: var(--card); color: var(--text); padding: 6px 12px;">
                        <?php foreach ($cats as $c): $sel = in_array($c, $selCats, true) ? 'selected' : ''; ?>
                            <option value="<?= htmlspecialchars($c) ?>" <?= $sel ?>><?= htmlspecialchars($c) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-row">
                    <label>Preço mínimo / máximo</label>
                    <?php $minPrice = isset($_GET['min_price']) ? htmlspecialchars($_GET['min_price']) : ''; $maxPrice = isset($_GET['max_price']) ? htmlspecialchars($_GET['max_price']) : ''; ?>
                    <div style="display:flex; gap:8px;">
                        <input type="number" step="0.01" name="min_price" value="<?= $minPrice ?>" placeholder="Mín" />
                        <input type="number" step="0.01" name="max_price" value="<?= $maxPrice ?>" placeholder="Máx" />
                    </div>
                </div>
                <div class="form-row">
                    <label>Itens por página</label>
                    <?php $perPageVal = isset($_GET['per_page']) ? (int)$_GET['per_page'] : (isset($_COOKIE['per_page']) ? (int)$_COOKIE['per_page'] : 20); ?>
                    <select name="per_page" style="height: 42px; border-radius: 10px; border: 1px solid var(--border); background: var(--card); color: var(--text); padding: 0 12px;">
                        <option value="20" <?= $perPageVal===20?'selected':''; ?>>20</option>
                        <option value="50" <?= $perPageVal===50?'selected':''; ?>>50</option>
                        <option value="100" <?= $perPageVal===100?'selected':''; ?>>100</option>
                    </select>
                </div>
                <div class="form-actions">
                    <button class="btn" type="submit">Filtrar</button>
                    <a class="btn" href="admin.php#produtos">Limpar</a>
                    <?php $exportParams = $_GET; unset($exportParams['page'], $exportParams['per_page']); $exportLink = 'export_products.php?' . http_build_query($exportParams); ?>
                    <a class="btn" href="<?= htmlspecialchars($exportLink) ?>" target="_blank">Exportar CSV</a>
                    <a class="btn" href="reports.php">Relatórios</a>
                </div>
            </form>

            <?php
            // Resumo de filtros ativos
            $hasActive = ($q !== '' || $sort !== '' || !empty($selCats) || $minPrice !== null || $maxPrice !== null || ($curSel !== ''));
            if ($hasActive): ?>
            <div class="chips" style="justify-content:flex-start; margin-bottom: 8px;">
                <?php if ($q !== ''): ?><span class="chip">Busca: "<?= htmlspecialchars($q) ?>"</span><?php endif; ?>
                <?php if ($sort === 'clicks'): ?><span class="chip">Ordenado: Cliques</span><?php endif; ?>
                <?php if ($sort === 'price'): ?><span class="chip">Ordenado: Preço</span><?php endif; ?>
                <?php foreach ($selCats as $c): ?><span class="chip">Categoria: <?= htmlspecialchars($c) ?></span><?php endforeach; ?>
                <?php if ($minPrice !== null): ?><span class="chip">Mín: R$ <?= number_format((float)$minPrice, 2, ',', '.') ?></span><?php endif; ?>
                <?php if ($maxPrice !== null): ?><span class="chip">Máx: R$ <?= number_format((float)$maxPrice, 2, ',', '.') ?></span><?php endif; ?>
                <?php if ($curSel !== ''): ?><span class="chip">Moeda: <?= htmlspecialchars($curSel) ?></span><?php endif; ?>
            </div>
            <?php endif; ?>

            <div class="card"><div class="card-body">
                <table style="width:100%; border-collapse:collapse;">
                    <thead>
                        <tr style="color:#cbd1e6;">
                            <th style="text-align:left; padding:6px;">ID</th>
                            <th style="text-align:left; padding:6px;">Nome</th>
                            <th style="text-align:left; padding:6px;">Categoria</th>
                            <th style="text-align:right; padding:6px;">Preço</th>
                            <th style="text-align:right; padding:6px;">Cliques</th>
                            <th style="text-align:right; padding:6px;">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($productsList as $p): ?>
                            <tr>
                                <td style="padding:6px;">#<?= (int)$p['id'] ?></td>
                                <td style="padding:6px;"><?= htmlspecialchars($p['name']) ?></td>
                                <td style="padding:6px;"><?= htmlspecialchars($p['category']) ?></td>
                                <td style="padding:6px; text-align:right;"><?= htmlspecialchars(format_money((float)$p['price'], (string)($p['currency'] ?? 'USD'))) ?></td>
                                <td style="padding:6px; text-align:right; font-weight:700;"><?= (int)$p['clicks_count'] ?></td>
                                <td style="padding:6px; text-align:right;">
                                    <a class="btn" href="product.php?id=<?= (int)$p['id'] ?>" target="_blank">Ver</a>
                                    <a class="btn" href="edit_product.php?id=<?= (int)$p['id'] ?>#produtos">Editar</a>
                                    <form method="post" action="delete_product.php#produtos" style="display:inline" onsubmit="return confirm('Excluir este produto?');">
                                        <input type="hidden" name="id" value="<?= (int)$p['id'] ?>" />
                                        <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>" />
                                        <button class="btn" type="submit" style="background:#c00; color:#fff;">Excluir</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div></div>

            <?php
                // Construção de links de paginação preservando filtros
                $params = $_GET;
                $prevPage = max(1, $page - 1);
                $nextPage = min($totalPages, $page + 1);
                $params['page'] = $prevPage; $prevLink = 'admin.php?' . http_build_query($params) . '#produtos';
                $params['page'] = $nextPage; $nextLink = 'admin.php?' . http_build_query($params) . '#produtos';
                // para links numéricos simples
                function page_link($p) {
                    $params = $_GET; $params['page'] = $p; return 'admin.php?' . http_build_query($params) . '#produtos';
                }
            ?>
            <div class="form-actions" style="margin-top:10px; display:flex; align-items:center; gap:10px; justify-content:space-between;">
                <div style="display:flex; gap:8px; align-items:center;">
                    <a class="btn" href="<?= htmlspecialchars($prevLink) ?>" <?= $page<=1?'style="opacity:.6; pointer-events:none;"':''; ?>>« Anterior</a>
                    <span class="desc">Página <?= (int)$page ?> de <?= (int)$totalPages ?> (<?= (int)$totalRows ?> itens)</span>
                    <a class="btn" href="<?= htmlspecialchars($nextLink) ?>" <?= $page>=$totalPages?'style="opacity:.6; pointer-events:none;"':''; ?>>Próxima »</a>
                </div>
                <div style="display:flex; gap:6px; align-items:center;">
                    <?php if ($totalPages <= 8): for ($p=1; $p<=$totalPages; $p++): ?>
                        <a class="btn" href="<?= htmlspecialchars(page_link($p)) ?>" <?= $p===$page?'style="background:#7c5cff; color:white;"':''; ?>><?= (int)$p ?></a>
                    <?php endfor; else: ?>
                        <a class="btn" href="<?= htmlspecialchars(page_link(1)) ?>" <?= $page===1?'style="background:#7c5cff; color:white;"':''; ?>>1</a>
                        <?php if ($page>3): ?><span class="desc">…</span><?php endif; ?>
                        <?php for ($p=max(2,$page-2); $p<=min($totalPages-1,$page+2); $p++): ?>
                            <a class="btn" href="<?= htmlspecialchars(page_link($p)) ?>" <?= $p===$page?'style="background:#7c5cff; color:white;"':''; ?>><?= (int)$p ?></a>
                        <?php endfor; ?>
                        <?php if ($page<$totalPages-2): ?><span class="desc">…</span><?php endif; ?>
                        <a class="btn" href="<?= htmlspecialchars(page_link($totalPages)) ?>" <?= $page===$totalPages?'style="background:#7c5cff; color:white;"':''; ?>><?= (int)$totalPages ?></a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-actions" style="margin-top:10px;">
                <a class="btn" href="export_clicks.php" target="_blank">Exportar cliques (CSV)</a>
            </div>
        </section>

        <?php
        // gráfico diário: últimos 30 dias
        $daily = [];
        $res = $db->query('SELECT DATE(created_at) as d, COUNT(*) as c FROM clicks WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY DATE(created_at) ORDER BY d ASC');
        if ($res) { while ($row = $res->fetch_assoc()) { $daily[] = $row; } $res->close(); }
        $maxC = 0; foreach ($daily as $r) { $maxC = max($maxC, (int)$r['c']); }
        ?>
        <section>
            <h2>Cliques por dia (30 dias)</h2>
            <div class="card"><div class="card-body" style="display:grid; gap:8px;">
                <?php if (!empty($daily)): ?>
                    <?php
                        $W = 720; $H = 220; $M = 28;
                        $n = count($daily);
                        $innerW = $W - 2*$M; $innerH = $H - 2*$M;
                        $stepX = $n > 1 ? ($innerW / ($n - 1)) : 0;
                        $path = '';
                        foreach ($daily as $i=>$r) {
                            $c = (int)$r['c'];
                            $x = $M + $i * $stepX;
                            $y = $H - $M - ($maxC > 0 ? ($c / $maxC) * $innerH : 0);
                            $cmd = ($i === 0) ? 'M' : 'L';
                            $path .= $cmd . ' ' . round($x,1) . ' ' . round($y,1) . ' ';
                        }
                        // pontos para marcação
                        $dots = [];
                        foreach ($daily as $i=>$r) {
                            $c = (int)$r['c'];
                            $x = $M + $i * $stepX;
                            $y = $H - $M - ($maxC > 0 ? ($c / $maxC) * $innerH : 0);
                            $dots[] = ['x'=>$x, 'y'=>$y, 'd'=>$r['d'], 'c'=>$c];
                        }
                    ?>
                    <?php
                        // Área sob a linha
                        $baseline = $H - $M;
                        $areaPath = '';
                        foreach ($daily as $i=>$r) {
                            $c = (int)$r['c'];
                            $x = $M + $i * $stepX;
                            $y = $H - $M - ($maxC > 0 ? ($c / $maxC) * $innerH : 0);
                            $cmd = ($i === 0) ? 'M' : 'L';
                            $areaPath .= $cmd . ' ' . round($x,1) . ' ' . round($y,1) . ' ';
                        }
                        if ($n > 1) {
                            $lastX = $M + ($n - 1) * $stepX;
                            $firstX = $M;
                            $areaPath .= ' L ' . round($lastX,1) . ' ' . round($baseline,1) . ' L ' . round($firstX,1) . ' ' . round($baseline,1) . ' Z';
                        }
                    ?>
                    <svg width="<?= $W ?>" height="<?= $H ?>" viewBox="0 0 <?= $W ?> <?= $H ?>" style="background:#0f1427; border-radius:12px;">
                        <!-- Área de plotagem -->
                        <rect x="<?= $M ?>" y="<?= $M ?>" width="<?= $innerW ?>" height="<?= $innerH ?>" fill="#0f1427" stroke="#222642" />
                        <!-- Área preenchida -->
                        <path d="<?= $areaPath ?>" fill="#7c5cff22" stroke="none" />
                        <!-- Linha -->
                        <path d="<?= $path ?>" fill="none" stroke="#7c5cff" stroke-width="2" />
                        <!-- Pontos com tooltips -->
                        <?php foreach ($dots as $pt): ?>
                            <circle cx="<?= round($pt['x'],1) ?>" cy="<?= round($pt['y'],1) ?>" r="3.5" fill="#7c5cff">
                                <title><?= htmlspecialchars($pt['d']) ?> • <?= (int)$pt['c'] ?> clique<?= $pt['c']==1?'':'s' ?></title>
                            </circle>
                        <?php endforeach; ?>
                        <!-- Eixo Y labels -->
                        <text x="6" y="<?= $M ?>" fill="#cbd1e6" font-size="12"><?= (int)$maxC ?></text>
                        <text x="6" y="<?= $H - $M ?>" fill="#cbd1e6" font-size="12">0</text>
                        <!-- Datas espaçadas -->
                        <?php foreach ($dots as $i=>$pt): if ($i % max(1, (int)floor($n/6)) !== 0) continue; ?>
                            <text x="<?= round($pt['x'],1) ?>" y="<?= $H - 6 ?>" fill="#cbd1e6" font-size="11" text-anchor="middle"><?= htmlspecialchars($pt['d']) ?></text>
                        <?php endforeach; ?>
                    </svg>
                <?php else: ?>
                    <p class="desc">Sem cliques registrados no período.</p>
                <?php endif; ?>
            </div></div>
        </section>
    </main>

    <footer class="site-footer">
        <div class="container footer-inner">
            <span>Use apenas produtos com direitos de afiliado válidos.</span>
        </div>
    </footer>
</body>
</html>