<?php
session_start();
require_once __DIR__ . '/config.php';
$db = get_db();
ensure_schema($db);

if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: admin.php#produtos'); exit; }

if (!check_csrf($_POST['csrf'] ?? null)) {
    $_SESSION['flash'] = ['msg'=>'Sessão expirada ou inválida.', 'type'=>'error'];
    header('Location: admin.php#produtos');
    exit;
}

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
if ($id <= 0) { $_SESSION['flash'] = ['msg'=>'ID inválido.', 'type'=>'error']; header('Location: admin.php#produtos'); exit; }

$ok = delete_product($db, $id);
$_SESSION['flash'] = $ok ? ['msg'=>'Produto excluído.', 'type'=>'success'] : ['msg'=>'Falha ao excluir produto.', 'type'=>'error'];
header('Location: admin.php#produtos');
exit;