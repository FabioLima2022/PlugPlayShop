// Busca e filtro por categoria
(function(){
  const search = document.getElementById('searchInput');
  const chips = document.getElementById('categoryChips');
  const cards = Array.from(document.querySelectorAll('#productGrid .card'));

  let activeCategory = 'all';

  function matches(card, term) {
    if (!term) return true;
    const name = card.getAttribute('data-name') || '';
    const cat = (card.getAttribute('data-category') || '').toLowerCase();
    term = term.toLowerCase();
    return name.includes(term) || cat.includes(term);
  }

  function matchesCategory(card) {
    if (activeCategory === 'all') return true;
    return (card.getAttribute('data-category') || '').toLowerCase() === activeCategory.toLowerCase();
  }

  function applyFilters() {
    const term = (search && search.value) ? search.value.trim() : '';
    cards.forEach(card => {
      const ok = matches(card, term) && matchesCategory(card);
      card.style.display = ok ? '' : 'none';
    });
  }

  if (search) {
    search.addEventListener('input', applyFilters);
  }
  if (chips) {
    chips.addEventListener('click', (e) => {
      const btn = e.target.closest('.chip');
      if (!btn) return;
      chips.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      activeCategory = btn.getAttribute('data-category') || 'all';
      applyFilters();
    });
  }

  // Click tracking básico em links de afiliado
  document.addEventListener('click', (e) => {
    const link = e.target.closest('a');
    if (!link) return;
    if (link.classList.contains('primary') && link.textContent.toLowerCase().includes('compr')) {
      console.log('[Affiliate] Click:', link.href);
    }
  });
})();