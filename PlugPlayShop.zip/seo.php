<?php
// Helpers de SEO para PlugPlay Shop

function seo_site_url(): string {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return $scheme . '://' . $host;
}

function seo_canonical(?string $path = null): string {
    $base = seo_site_url();
    $uri = $path ?? ($_SERVER['REQUEST_URI'] ?? '/');
    $url = rtrim($base, '/') . $uri;
    return htmlspecialchars($url);
}

function seo_meta(array $opts = []): void {
    $title = $opts['title'] ?? 'PlugPlay Shop';
    $desc = $opts['description'] ?? 'Descubra produtos selecionados com avaliações, imagens e links de compra.';
    $canonical = $opts['canonical'] ?? seo_canonical();
    $image = $opts['image'] ?? null;
    $type = $opts['type'] ?? 'website';
    $siteName = $opts['site_name'] ?? 'PlugPlay Shop';
    $locale = $opts['locale'] ?? 'pt_BR';

    echo '<link rel="canonical" href="' . $canonical . '" />' . "\n";
    echo '<meta name="description" content="' . htmlspecialchars($desc) . '" />' . "\n";
    echo '<meta property="og:title" content="' . htmlspecialchars($title) . '" />' . "\n";
    echo '<meta property="og:description" content="' . htmlspecialchars($desc) . '" />' . "\n";
    echo '<meta property="og:type" content="' . htmlspecialchars($type) . '" />' . "\n";
    echo '<meta property="og:url" content="' . $canonical . '" />' . "\n";
    echo '<meta property="og:site_name" content="' . htmlspecialchars($siteName) . '" />' . "\n";
    echo '<meta property="og:locale" content="' . htmlspecialchars($locale) . '" />' . "\n";
    if ($image) {
        echo '<meta property="og:image" content="' . htmlspecialchars($image) . '" />' . "\n";
        echo '<meta name="twitter:image" content="' . htmlspecialchars($image) . '" />' . "\n";
    }
    echo '<meta name="twitter:card" content="' . ($image ? 'summary_large_image' : 'summary') . '" />' . "\n";
    echo '<meta name="twitter:title" content="' . htmlspecialchars($title) . '" />' . "\n";
    echo '<meta name="twitter:description" content="' . htmlspecialchars($desc) . '" />' . "\n";
}

function seo_jsonld(array $schema): void {
    echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
}